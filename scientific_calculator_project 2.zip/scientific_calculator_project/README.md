# Scientific Calculator (C++)

A simple console-based Scientific Calculator written in C++. 

## Features

- Addition, Subtraction, Multiplication, Division
- Power and Square Root calculations
- Trigonometric functions (Sine, Cosine, Tangent)
- Natural Logarithm calculation
- Input validation for incorrect inputs
- User-friendly text interface

## How to Compile and Run

```bash
g++ -o scientific_calculator scientific_calculator.cpp
./scientific_calculator
```

## Project Purpose

- Functions and switch statements
- User input handling
- Input validation
- Use of standard C++ math libraries (`cmath`)
- Loops and menu-driven CLI design

## Future Improvements

- Support for degree/radian toggle
- Factorial, inverse trig functions, advanced math operations
- GUI version or Web version
- Unit tests for operations

